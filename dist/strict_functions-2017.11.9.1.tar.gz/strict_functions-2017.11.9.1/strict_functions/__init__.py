# -*- coding: utf-8 -*-
# @Author: cody
# @Date:   2016-10-14 13:26:43
# @Last Modified 2017-11-09
# @Last Modified time: 2017-11-09 11:49:50

import sys
import os.path

sys.path.append(os.path.dirname(__file__))

del sys
del os

from input_types import input_types
from output_type import output_type
from strict_defaults import strict_defaults
